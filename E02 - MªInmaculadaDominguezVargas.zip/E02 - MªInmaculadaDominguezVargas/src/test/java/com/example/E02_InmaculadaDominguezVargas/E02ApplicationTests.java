package com.example.E02_InmaculadaDominguezVargas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class E02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
