package com.example.E02_InmaculadaDominguezVargas;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MonumentoRepository extends JpaRepository <Monumento, Long> {
}
