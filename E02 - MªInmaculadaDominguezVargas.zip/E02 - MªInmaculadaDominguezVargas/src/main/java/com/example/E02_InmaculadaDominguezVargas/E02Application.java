package com.example.E02_InmaculadaDominguezVargas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class E02Application {

	public static void main(String[] args) {
		SpringApplication.run(E02Application.class, args);
	}

}
