import csv

with open("climatologia.csv", )