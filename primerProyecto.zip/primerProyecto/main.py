# This is a sample Python script.

# Press Mayús+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.

import math


# Ejercicio 1

def area_rectangulo(b, h):
    area = b*h

    return area


resultado = area_rectangulo(15, 10)
print(resultado)


# Ejercicio 2

def area_circulo(r):
    area = pow(r, 2) * math.pi

    return area


resultado = area_circulo(5)
print(resultado)


# Ejercicio 3

def relacion(a, b):
    if a > b:
        return 1
    if a < b:
        return -1

    else:
        return 0


resultado = relacion(5, 10)
print(resultado)


# Ejercicio 4

def intermedio(a, b):
    punto_intermedio = (a+b)/2

    return punto_intermedio


resultado = intermedio(-12, 24)
print(resultado)


#Ejercicio 5

def recortar(numero, minimo, maximo):
    if numero < minimo:
        return minimo
    if numero > maximo:
        return maximo
    else:
        numero


resultado = recortar(15, 0, 10)
print(resultado)


from io import open


fichero = open("fichero.txt", "w")

texto = "Todos los alumnos de 2º"

fichero.write(texto)

fichero.close()

import pickle

